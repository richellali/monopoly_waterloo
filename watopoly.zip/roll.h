#ifndef __ROLL__
#define __ROLL__

int rollnum1();
int rollnum2();
int rollnum3();
int rollnum4();
int rollnum5();
int rollnum6();
#endif
